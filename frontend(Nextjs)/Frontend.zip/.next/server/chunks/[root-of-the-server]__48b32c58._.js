module.exports = {

"[project]/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/favicon--route-entry.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET),
    "dynamic": (()=>dynamic)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("AAABAAEAICAAAAEAIACoEAAAFgAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAACMuAAAjLgAAAAAAAAAAAAD////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Y2Nj/pqam/6Ojo/+jo6P/o6Oj/6Ojo/+jo6P/mpqa/5qamv+jo6P/o6Oj/6Ojo/+jo6P/o6Oj/6ampv/Y2Nj/////////////////////////////////////////////////////////////////////////////////7u7u/0NDQ/8CAgL/BAQE/wQEBP8EBAT/BAQE/wQEBP8BAQH/AQEB/wQEBP8EBAT/BAQE/wQEBP8EBAT/AgIC/0NDQ//u7u7////////////////////////////////////////////////////////////////////////////u7u7/QkJC/wMDA/8FBQX/BQUF/wUFBf8FBQX/AwMD/wAAAP8AAAD/AwMD/wUFBf8FBQX/BQUF/wUFBf8DAwP/QkJC/+7u7v/////////////////////////////////////////////////////////////////////////////////Y2Nj/p6en/6Wlpf+lpaX/paWl/6ioqP9paWn/AwMD/wMDA/9paWn/qKio/6Wlpf+lpaX/paWl/6enp//Y2Nj//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////6Kiov8EBAT/BAQE/6Kiov/////////////////////////////////////////////////////////////////////////////////////////////////6+vr/7e3t/+Li4v/p6en/9vb2//7+/v//////////////////////oqKi/wQEBP8EBAT/oqKi///////////////////////+/v7/9vb2/+np6f/i4uL/7e3t//r6+v/////////////////////////////////s7Oz/paWl/1tbW/8wMDD/JCQk/yoqKv9KSkr/ioqK/9ra2v/+/v7///////////+ioqL/BAQE/wQEBP+ioqL////////////+/v7/2tra/4qKiv9JSUn/Kioq/yUlJf8wMDD/W1tb/6Wlpf/t7e3/////////////////z8/P/0hISP8ICAj/AAAA/wAAAP8AAAD/AAAA/wAAAP8CAgL/KCgo/6Ojo//9/f3//////6Kiov8EBAT/BAQE/6Kiov///////f39/6Ojo/8oKCj/AgIC/wAAAP8AAAD/AAAA/wAAAP8AAAD/CAgI/0hISP/Pz8////////////9ubm7/AAAA/wAAAP8SEhL/Pz8//1VVVf9KSkr/ISEh/wICAv8AAAD/LCws/+np6f//////oqKi/wQEBP8EBAT/oqKi///////p6en/LCws/wAAAP8CAgL/ISEh/0pKSv9VVVX/Pz8//xISEv8AAAD/AAAA/25ubv///////////42Njf8AAAD/AAAA/3Nzc//y8vL//f39//j4+P+xsbH/Dw8P/wAAAP9ISEj/8/Pz//////+ioqL/BAQE/wQEBP+ioqL///////Pz8/9ISEj/AAAA/w8PD/+xsbH/+Pj4//39/f/y8vL/dHR0/wAAAP8AAAD/jY2N////////////0tLS/xsbG/8AAAD/SUlJ//Pz8////////////42Njf8BAQH/AgIC/5SUlP///////////6Kiov8EBAT/BAQE/6Kiov///////////5SUlP8CAgL/AQEB/42Njf////////////Pz8/9JSUn/AAAA/xoaGv/S0tL////////////5+fn/V1dX/wAAAP8SEhL/w8PD///////v7+//QEBA/wAAAP8gICD/19fX////////////oqKi/wQEBP8EBAT/oqKi////////////2NjY/yEhIf8AAAD/QEBA/+/v7///////w8PD/xISEv8AAAD/WFhY//n5+f////////////////+lpaX/BgYG/wAAAP96enr//////729vf8PDw//AAAA/2BgYP/6+vr///////////+ioqL/BAQE/wQEBP+ioqL////////////6+vr/YGBg/wAAAP8PDw//vb29//////96enr/AAAA/wYGBv+kpKT//////////////////////+Li4v8sLCz/AAAA/zIyMv/m5ub/cnJy/wAAAP8ICAj/ra2t/////////////////6Kiov8EBAT/BAQE/6Kiov////////////////+tra3/CAgI/wAAAP9ycnL/5+fn/zMzM/8AAAD/LCws/+Li4v///////////////////////v7+/3Fxcf8AAAD/CwsL/4+Pj/8uLi7/AAAA/zExMf/n5+f/////////////////oqKi/wQEBP8EBAT/oqKi/////////////////+fn5/8yMjL/AAAA/y4uLv+Pj4//CwsL/wAAAP9xcXH//v7+////////////////////////////vLy8/w4ODv8AAAD/Hh4e/wYGBv8AAAD/eXl5//////////////////////+ioqL/BAQE/wQEBP+ioqL//////////////////////3l5ef8AAAD/BgYG/x0dHf8AAAD/Dg4O/729vf/////////////////////////////////v7+//Pz8//wAAAP8AAAD/AAAA/xISEv/ExMT//////////////////////6Kiov8EBAT/BAQE/6Kiov//////////////////////xMTE/xISEv8AAAD/AAAA/wAAAP8/Pz//7+/v//////////////////////////////////////+Li4v/AAAA/wAAAP8AAAD/SEhI//Pz8///////////////////////oqKi/wQEBP8EBAT/oqKi///////////////////////z8/P/SEhI/wAAAP8AAAD/AAAA/4uLi////////////////////////////////////////////9LS0v8cHBz/AAAA/wICAv+VlZX///////////////////////////+ioqL/BAQE/wQEBP+ioqL///////////////////////////+VlZX/AgIC/wAAAP8cHBz/0tLS/////////////////////////////////+3t7f+CgoL/U1NT/xMTE/8AAAD/BwcH/2ZmZv+mpqb/zc3N//Dw8P/+/v7//////6Kiov8EBAT/BAQE/6Kiov///////v7+//Dw8P/Nzc3/pqam/2ZmZv8HBwf/AAAA/xMTE/9TU1P/goKC/+3t7f//////////////////////srKy/woKCv8AAAD/AAAA/wAAAP8AAAD/AAAA/wMDA/8WFhb/PDw8/35+fv/IyMj/lpaW/wUFBf8FBQX/lpaW/8jIyP9+fn7/PDw8/xUVFf8DAwP/AAAA/wAAAP8AAAD/AAAA/wAAAP8KCgr/srKy///////////////////////X19f/RERE/yAgIP8hISH/ISEh/xsbG/8NDQ3/AQEB/wAAAP8AAAD/AQEB/xQUFP8iIiL/AgIC/wICAv8iIiL/ExMT/wEBAf8AAAD/AAAA/wEBAf8NDQ3/Gxsb/yEhIf8hISH/ICAg/0RERP/X19f///////////////////////7+/v/t7e3/3d3d/93d3f/c3Nz/1NTU/729vf+Wlpb/Xl5e/ycnJ/8FBQX/AAAA/wAAAP8AAAD/AAAA/wAAAP8AAAD/BQUF/ycnJ/9eXl7/lpaW/729vf/U1NT/3Nzc/93d3f/e3t7/7u7u//7+/v/////////////////////////////////////////////////////////////////8/Pz/4ODg/6enp/9aWlr/FRUV/wAAAP8AAAD/ExMT/1dXV/+np6f/4ODg//z8/P////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+/+Kior/AgIC/wICAv+JiYn/+fn5/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////6Kiov8EBAT/BAQE/6Kiov//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wcHB/xoaGv8aGhr/wcHB///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////6+vr/wcHB/8HBwf/6+vr/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=", 'base64');
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
}
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__48b32c58._.js.map