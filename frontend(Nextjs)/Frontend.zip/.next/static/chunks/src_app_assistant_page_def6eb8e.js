(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_0c0bfa2b._.js",
  "static/chunks/node_modules_023d511b._.js"
],
    source: "dynamic"
});
