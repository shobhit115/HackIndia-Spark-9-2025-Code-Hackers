(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_64a53d87._.js",
  "static/chunks/src_0531813b._.js"
],
    source: "dynamic"
});
