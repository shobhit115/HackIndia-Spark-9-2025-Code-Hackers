// "use client";

// import { useRef, useState, useEffect } from "react";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import {
//   Select,
//   SelectTrigger,
//   SelectValue,
//   SelectContent,
//   SelectItem,
// } from "@/components/ui/select";
// import { Card, CardContent } from "@/components/ui/card";
// import { ScrollArea } from "@/components/ui/scroll-area";
// import { Textarea } from "@/components/ui/textarea";
// import { Loader2 } from "lucide-react";
// import { Label } from "@/components/ui/label";
// import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

// export default function AIChatbotScreen() {
//   const [language, setLanguage] = useState("English");
//   const [legalArea, setLegalArea] = useState("");
//   const [timeframe, setTimeframe] = useState("all-time");
//   const [file, setFile] = useState(null);
//   const [fileError, setFileError] = useState("");
//   const [chatStarted, setChatStarted] = useState(false);
//   const [isListening, setIsListening] = useState(false);
//   const [messages, setMessages] = useState([]);
//   const [input, setInput] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [apiError, setApiError] = useState("");
//   const fileInputRef = useRef();
//   const messagesEndRef = useRef(null);
//   const scrollAreaRef = useRef(null);
//   const recognitionRef = useRef(null);

//   useEffect(() => {
//     if (typeof window !== "undefined") {
//       const SpeechRecognition =
//         window.SpeechRecognition || window.webkitSpeechRecognition;
//       if (SpeechRecognition) {
//         recognitionRef.current = new SpeechRecognition();

//         recognitionRef.current.continuous = true;
//         recognitionRef.current.interimResults = true;

//         recognitionRef.current.onresult = (event) => {
//           let interimTranscript = "";
//           for (let i = event.resultIndex; i < event.results.length; i++) {
//             const transcript = event.results[i][0].transcript;
//             if (event.results[i].isFinal) {
//               setInput((prevInput) => prevInput + transcript);
//             } else {
//               interimTranscript += transcript;
//             }
//           }
//         };

//         recognitionRef.current.onstart = () => {
//           console.log("Speech recognition started");
//         };

//         recognitionRef.current.onend = () => {
//           console.log("Speech recognition ended");
//           setIsListening(false);
//         };

//         recognitionRef.current.onerror = (event) => {
//           console.error("Speech recognition error", event);
//           let errorMessage = "Speech recognition error. Please try again.";
//           switch (event.error) {
//             case "no-speech":
//               errorMessage = "No speech was detected. Please try again.";
//               break;
//             case "audio-capture":
//               errorMessage =
//                 "Failed to capture audio. Check microphone permissions.";
//               break;
//             case "not-allowed":
//               errorMessage = "Permission to use microphone was denied.";
//               break;
//             case "service-not-allowed":
//               errorMessage = "The speech recognition service is not allowed.";
//               break;
//             default:
//               errorMessage = `Speech recognition error: ${event.error}.`;
//           }
//           setApiError(errorMessage);
//           setIsListening(false);
//         };
//       } else {
//         console.warn("Speech Recognition API not supported in this browser.");
//         setApiError("Speech Recognition API not supported in this browser.");
//       }
//     }
//   }, []);

//   // Smooth scroll handling
//   useEffect(() => {
//     const scrollEl = scrollAreaRef.current;
//     if (scrollEl) {
//       const shouldScroll =
//         scrollEl.scrollTop + scrollEl.clientHeight >=
//         scrollEl.scrollHeight - 50;
//       if (shouldScroll) {
//         scrollEl.scrollTo({
//           top: scrollEl.scrollHeight,
//           behavior: "smooth",
//         });
//       }
//     }
//   }, [messages, loading]);

//   const LANGUAGES = [
//     { value: "English", label: "English" },
//     { value: "Hindi", label: "हिन्दी" },
//     { value: "Bengali", label: "বাংলা" },
//     { value: "Telugu", label: "తెలుగు" },
//     { value: "Tamil", label: "தமிழ்" },
//     { value: "Marathi", label: "मराठी" },
//     { value: "Gujarati", label: "ગુજરાતી" },
//     { value: "Kannada", label: "ಕನ್ನಡ" },
//     { value: "Malayalam", label: "മലയാളം" },
//     { value: "Punjabi", label: "ਪੰਜਾਬੀ" },
//     { value: "Odia", label: "ଓଡ଼ିଆ" },
//     { value: "Assamese", label: "অসমীয়া" },
//   ];

//   const TIMEFRAMES = [
//     { value: "all-time", label: "All Time" },
//     { value: "past-year", label: "Past Year" },
//     { value: "past-month", label: "Past Month" },
//     { value: "past-week", label: "Past Week" },
//   ];

//   const LEGAL_AREAS = [
//     { value: "IPC", label: "IPC" },
//     { value: "RTI", label: "RTI" },
//     { value: "Labor", label: "Labor Laws" },
//     { value: "Other", label: "Other" },
//   ];

//   function handleFileChange(e) {
//     const f = e.target.files[0];
//     if (f && f.size > 5 * 1024 * 1024) {
//       setFileError("File size exceeds 5MB.");
//       setFile(null);
//     } else {
//       setFileError("");
//       setFile(f);
//     }
//   }

//   function handleStartChat() {
//     if (!language || !legalArea || !timeframe) {
//       return setApiError("Please fill all filters");
//     }
//     setApiError("");
//     setChatStarted(true);
//   }

//   async function handleSend() {
//     if (!input.trim()) return;
//     setLoading(true);
//     setApiError("");

//     try {
//       // Add user message immediately
//       const userMessage = { role: "user", content: input };
//       setMessages((prev) => [...prev, userMessage]);
//       setInput("");

//       setMessages((prev) => [
//         ...prev,
//         {
//           role: "ai",
//           content: `
//           Yeah <strong>Great</strong> Choice.
//           `,
//         },
//       ]);
//       return;

//       // Prepare message history including new message
//       const messageHistory = [...messages, userMessage];

//       // Prepare form data
//       const formData = new FormData();
//       formData.append("message", input);
//       formData.append("language", language);
//       formData.append("legalArea", legalArea);
//       formData.append("timeframe", timeframe);
//       formData.append("history", JSON.stringify(messageHistory)); // Send full history
//       if (file) formData.append("file", file);

//       // API call
//       const res = await fetch("/api/ai-chat", {
//         method: "POST",
//         body: formData,
//       });

//       let data;
//       if (res.ok) {
//         // Parse success response
//         try {
//           data = await res.json();
//           setMessages((prev) => [...prev, { role: "ai", content: data.reply }]);
//         } catch (jsonError) {
//           console.error("JSON Parsing Error:", jsonError);
//           throw new Error("Invalid response format from server");
//         }
//       } else {
//         // Handle error responses
//         let errorMsg = "Request failed";
//         try {
//           const errorData = await res.json();
//           errorMsg = errorData.error || errorMsg;
//         } catch {
//           // If response isn't JSON, read as text
//           const textData = await res.text();
//           errorMsg = textData.startsWith("<")
//             ? "Server error occurred. Please try again later."
//             : textData || errorMsg;
//         }
//         throw new Error(errorMsg);
//       }
//     } catch (err) {
//       console.error("API Error:", err);
//       setApiError(
//         err.message || "Failed to process your request. Please try again."
//       );
//       // Remove last user message if error occurred
//       setMessages((prev) => prev.filter((m, i) => i !== prev.length - 1));
//     } finally {
//       setLoading(false);
//     }
//   }

//   function handleKeyDown(e) {
//     if (e.key === "Enter" && !e.shiftKey) {
//       e.preventDefault();
//       if (!loading && !isListening) handleSend();
//     }
//   }

//   function handleReset() {
//     setMessages([]);
//     setInput("");
//     setFile(null);
//     setFileError("");
//     setApiError("");
//     setChatStarted(false);
//     setLanguage("");
//     setLegalArea("");
//     setTimeframe("");
//     if (fileInputRef.current) fileInputRef.current.value = "";
//   }

//   // Auto-scroll to bottom
//   useEffect(() => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
//   }, [messages, loading]);

//   const startListening = () => {
//     if (recognitionRef.current) {
//       setIsListening(true);
//       setInput("");
//       recognitionRef.current.start();
//     }
//   };

//   const stopListening = () => {
//     if (recognitionRef.current) {
//       recognitionRef.current.stop();
//       setIsListening(false);
//     }
//   };
//   // ... (keep all existing handler functions)

//   return (
//     <div className="min-h-screen bg-white">
//       {!chatStarted ? (
//         <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
//           <Card className="border">
//             <CardContent className="p-8">
//               <h2 className="text-2xl font-semibold text-gray-900 mb-8">
//                 New Legal Consultation
//               </h2>

//               <div className="space-y-8">
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                   <div className="space-y-2">
//                     <Label className="text-sm font-medium text-gray-700">
//                       Language
//                     </Label>
//                     <Select value={language} onValueChange={setLanguage}>
//                       <SelectTrigger className="border-gray-300 hover:border-gray-400">
//                         <SelectValue placeholder="Select language" />
//                       </SelectTrigger>
//                       <SelectContent className="max-h-[300px]">
//                         {LANGUAGES.map((lang) => (
//                           <SelectItem key={lang.value} value={lang.value}>
//                             {lang.label}
//                           </SelectItem>
//                         ))}
//                       </SelectContent>
//                     </Select>
//                   </div>

//                   <div className="space-y-2">
//                     <Label className="text-sm font-medium text-gray-700">
//                       Timeframe
//                     </Label>
//                     <Select value={timeframe} onValueChange={setTimeframe}>
//                       <SelectTrigger className="border-gray-300 hover:border-gray-400">
//                         <SelectValue placeholder="Select timeframe" />
//                       </SelectTrigger>
//                       <SelectContent>
//                         {TIMEFRAMES.map((time) => (
//                           <SelectItem key={time.value} value={time.value}>
//                             {time.label}
//                           </SelectItem>
//                         ))}
//                       </SelectContent>
//                     </Select>
//                   </div>
//                 </div>

//                 <div className="space-y-2">
//                   <Label className="text-sm font-medium text-gray-700">
//                     Upload Document
//                   </Label>
//                   <Input
//                     ref={fileInputRef}
//                     type="file"
//                     accept=".pdf,.txt,.docx"
//                     onChange={handleFileChange}
//                     className="border-gray-300 hover:border-gray-400 cursor-pointer"
//                   />
//                   {fileError && (
//                     <div className="text-red-500 text-sm mt-1">{fileError}</div>
//                   )}
//                 </div>

//                 <div className="space-y-2">
//                   <Label className="text-sm font-medium text-gray-700">
//                     Legal Area
//                   </Label>
//                   <RadioGroup
//                     value={legalArea}
//                     onValueChange={setLegalArea}
//                     className="grid grid-cols-2 md:grid-cols-4 gap-4"
//                   >
//                     {LEGAL_AREAS.map((area) => (
//                       <div
//                         key={area.value}
//                         className="flex items-center space-x-2"
//                       >
//                         <RadioGroupItem
//                           value={area.value}
//                           id={area.value}
//                           className="border-gray-300 text-gray-900"
//                         />
//                         <Label
//                           htmlFor={area.value}
//                           className="text-sm text-gray-700"
//                         >
//                           {area.label}
//                         </Label>
//                       </div>
//                     ))}
//                   </RadioGroup>
//                 </div>

//                 {apiError && (
//                   <div className="text-red-500 text-sm mt-4 text-center">
//                     {apiError}
//                   </div>
//                 )}

//                 <Button
//                   className="w-full bg-gray-900 hover:bg-gray-800 text-white border border-gray-900"
//                   onClick={handleStartChat}
//                   disabled={!legalArea || !!fileError}
//                 >
//                   Start Consultation
//                 </Button>
//               </div>
//             </CardContent>
//           </Card>
//         </div>
//       ) : (
//         <div className="max-w-7xl mx-auto h-[90vh] flex flex-col p-6">
//           <Card className="flex-1 flex flex-col border mb-4">
//             <CardContent className="flex-1 flex flex-col p-6 pb-0">
//               <div className="flex items-center justify-between mb-6 pb-4 border-b">
//                 <div>
//                   <h3 className="text-xl font-semibold text-gray-900">
//                     Legal Consultation
//                   </h3>
//                   <div className="text-sm text-gray-500 mt-1">
//                     {language} • {legalArea} •{" "}
//                     {TIMEFRAMES.find((t) => t.value === timeframe)?.label}
//                   </div>
//                 </div>
//                 <Button
//                   variant="outline"
//                   onClick={handleReset}
//                   className="text-gray-700 hover:bg-gray-50 border-gray-300"
//                 >
//                   Reset Session
//                 </Button>
//               </div>

//               <ScrollArea
//                 ref={scrollAreaRef}
//                 className="flex-1 pr-4 mb-4"
//                 onScroll={() => {
//                   // Handle manual scroll if needed
//                 }}
//               >
//                 <div className="space-y-4">
//                   {messages.length === 0 && (
//                     <div className="text-center text-gray-400 py-12">
//                       <div className="text-lg font-medium">
//                         Begin your legal consultation
//                       </div>
//                       <div className="text-sm mt-2">
//                         Ask about case law, regulations, or document analysis
//                       </div>
//                     </div>
//                   )}

//                   {messages.map((msg, i) => (
//                     <div
//                       key={i}
//                       className={`flex ${
//                         msg.role === "user" ? "justify-end" : "justify-start"
//                       }`}
//                     >
//                       <div
//                         className={`max-w-[75%] px-4 py-3 rounded-lg ${
//                           msg.role === "user"
//                             ? "bg-gray-900 text-white"
//                             : "bg-gray-50 text-gray-900"
//                         }`}
//                       >
//                         {msg.role == "user" ? (
//                           msg.content
//                         ) : (
//                           <div
//                             dangerouslySetInnerHTML={{ __html: msg.content }}
//                           />
//                         )}
//                       </div>
//                     </div>
//                   ))}

//                   {loading && (
//                     <div className="flex justify-start">
//                       <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-lg">
//                         <Loader2 className="animate-spin w-5 h-5 text-gray-500" />
//                         <span className="text-gray-600">Analyzing...</span>
//                       </div>
//                     </div>
//                   )}
//                   <div ref={messagesEndRef} />
//                 </div>
//               </ScrollArea>

//               <div className="sticky bottom-0 bg-white pt-4 pb-4">
//                 <form
//                   onSubmit={(e) => {
//                     e.preventDefault();
//                     handleSend();
//                   }}
//                   className="bg-white border-t pt-4"
//                 >
//                   {apiError && (
//                     <div className="text-red-500 text-sm mb-2">{apiError}</div>
//                   )}
//                   <div className="flex gap-3">
//                     <Textarea
//                       className="flex-1 resize-none min-h-[100px] text-sm border-gray-300"
//                       placeholder="Type your legal query..."
//                       value={input}
//                       onChange={(e) => setInput(e.target.value)}
//                       onKeyDown={handleKeyDown}
//                       disabled={loading || isListening}
//                     />
//                     <Button
//                       type="button"
//                       onClick={isListening ? stopListening : startListening}
//                       disabled={loading}
//                       className="self-end bg-blue-500 hover:bg-blue-700 text-white"
//                     >
//                       {isListening ? "Stop Listening" : "Start Listening"}
//                     </Button>
//                     <Button
//                       type="submit"
//                       disabled={loading || !input.trim()}
//                       className="self-end bg-gray-900 hover:bg-gray-800 text-white border border-gray-900"
//                     >
//                       {loading ? (
//                         <Loader2 className="animate-spin h-5 w-5" />
//                       ) : (
//                         "Send"
//                       )}
//                     </Button>
//                   </div>
//                   {file && (
//                     <div className="text-sm text-gray-500 mt-2 flex items-center gap-2">
//                       <span>📎 Attached:</span>
//                       <span className="font-medium">{file.name}</span>
//                     </div>
//                   )}
//                 </form>
//               </div>
//             </CardContent>
//           </Card>
//         </div>
//       )}
//     </div>
//   );
// }

// app/chat/page.jsx

"use client";

import { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function AIChatbotScreen() {
  const [language, setLanguage] = useState("English");
  const [legalArea, setLegalArea] = useState("");
  const [timeframe, setTimeframe] = useState("all-time");
  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState("");
  const [chatStarted, setChatStarted] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState("");
  const fileInputRef = useRef();
  const messagesEndRef = useRef(null);
  const scrollAreaRef = useRef(null);

  // Smooth scroll handling
  useEffect(() => {
    const scrollEl = scrollAreaRef.current;
    if (scrollEl) {
      const shouldScroll =
        scrollEl.scrollTop + scrollEl.clientHeight >=
        scrollEl.scrollHeight - 50;
      if (shouldScroll) {
        scrollEl.scrollTo({
          top: scrollEl.scrollHeight,
          behavior: "smooth",
        });
      }
    }
  }, [messages, loading]);

  const LANGUAGES = [
    { value: "English", label: "English" },
    { value: "Hindi", label: "हिन्दी" },
    { value: "Bengali", label: "বাংলা" },
    { value: "Telugu", label: "తెలుగు" },
    { value: "Tamil", label: "தமிழ்" },
    { value: "Marathi", label: "मराठी" },
    { value: "Gujarati", label: "ગુજરાતી" },
    { value: "Kannada", label: "ಕನ್ನಡ" },
    { value: "Malayalam", label: "മലയാളം" },
    { value: "Punjabi", label: "ਪੰਜਾਬੀ" },
    { value: "Odia", label: "ଓଡ଼ିଆ" },
    { value: "Assamese", label: "অসমীয়া" },
  ];

  const TIMEFRAMES = [
    { value: "all-time", label: "All Time" },
    { value: "past-year", label: "Past Year" },
    { value: "past-month", label: "Past Month" },
    { value: "past-week", label: "Past Week" },
  ];

  const LEGAL_AREAS = [
    { value: "IPC", label: "IPC" },
    { value: "RTI", label: "RTI" },
    { value: "Labor", label: "Labor Laws" },
    { value: "Other", label: "Other" },
  ];

  function handleFileChange(e) {
    const f = e.target.files[0];
    if (f && f.size > 5 * 1024 * 1024) {
      setFileError("File size exceeds 5MB.");
      setFile(null);
    } else {
      setFileError("");
      setFile(f);
    }
  }

  function handleStartChat() {
    if (!language || !legalArea || !timeframe) {
      return setApiError("Please fill all filters");
    }
    setApiError("");
    setChatStarted(true);
  }

  async function handleSend() {
    if (!input.trim()) return;
    setLoading(true);
    setApiError("");

    try {
      // Add user message immediately
      const userMessage = { role: "user", content: input };
      setMessages((prev) => [...prev, userMessage]);
      setInput("");

      // setMessages((prev) => [
      //   ...prev,
      //   {
      //     role: "ai",
      //     content: `
      //     Yeah <strong>Great</strong> Choice.
      //     `,
      //   },
      // ]);
      // return;

      // Prepare message history including new message
      const messageHistory = [...messages, userMessage];

      // Prepare form data
      const formData = new FormData();
      formData.append("message", input);
      formData.append("language", language);
      formData.append("legalArea", legalArea);
      formData.append("timeframe", timeframe);
      formData.append("history", JSON.stringify(messageHistory)); // Send full history
      if (file) formData.append("file", file);

      // API call
      const res = await fetch("/api/ai-chat", {
        method: "POST",
        body: formData,
      });

      let data;
      if (res.ok) {
        // Parse success response
        try {
          data = await res.json();
          setMessages((prev) => [...prev, { role: "ai", content: data.reply }]);
        } catch (jsonError) {
          console.error("JSON Parsing Error:", jsonError);
          throw new Error("Invalid response format from server");
        }
      } else {
        // Handle error responses
        let errorMsg = "Request failed";
        try {
          const errorData = await res.json();
          errorMsg = errorData.error || errorMsg;
        } catch {
          // If response isn't JSON, read as text
          const textData = await res.text();
          errorMsg = textData.startsWith("<")
            ? "Server error occurred. Please try again later."
            : textData || errorMsg;
        }
        throw new Error(errorMsg);
      }
    } catch (err) {
      console.error("API Error:", err);
      setApiError(
        err.message || "Failed to process your request. Please try again."
      );
      // Remove last user message if error occurred
      setMessages((prev) => prev.filter((m, i) => i !== prev.length - 1));
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (!loading) handleSend();
    }
  }

  function handleReset() {
    setMessages([]);
    setInput("");
    setFile(null);
    setFileError("");
    setApiError("");
    setChatStarted(false);
    setLanguage("");
    setLegalArea("");
    setTimeframe("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // ... (keep all existing handler functions)

  return (
    <div className="min-h-screen bg-white">
      {!chatStarted ? (
        <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <Card className="border">
            <CardContent className="p-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-8">
                New Legal Consultation
              </h2>

              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">
                      Language
                    </Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="border-gray-300 hover:border-gray-400">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent className="max-h-[300px]">
                        {LANGUAGES.map((lang) => (
                          <SelectItem key={lang.value} value={lang.value}>
                            {lang.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">
                      Timeframe
                    </Label>
                    <Select value={timeframe} onValueChange={setTimeframe}>
                      <SelectTrigger className="border-gray-300 hover:border-gray-400">
                        <SelectValue placeholder="Select timeframe" />
                      </SelectTrigger>
                      <SelectContent>
                        {TIMEFRAMES.map((time) => (
                          <SelectItem key={time.value} value={time.value}>
                            {time.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700">
                    Upload Document
                  </Label>
                  <Input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.txt,.docx"
                    onChange={handleFileChange}
                    className="border-gray-300 hover:border-gray-400 cursor-pointer"
                  />
                  {fileError && (
                    <div className="text-red-500 text-sm mt-1">{fileError}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700">
                    Legal Area
                  </Label>
                  <RadioGroup
                    value={legalArea}
                    onValueChange={setLegalArea}
                    className="grid grid-cols-2 md:grid-cols-4 gap-4"
                  >
                    {LEGAL_AREAS.map((area) => (
                      <div
                        key={area.value}
                        className="flex items-center space-x-2"
                      >
                        <RadioGroupItem
                          value={area.value}
                          id={area.value}
                          className="border-gray-300 text-gray-900"
                        />
                        <Label
                          htmlFor={area.value}
                          className="text-sm text-gray-700"
                        >
                          {area.label}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>

                {apiError && (
                  <div className="text-red-500 text-sm mt-4 text-center">
                    {apiError}
                  </div>
                )}

                <Button
                  className="w-full bg-gray-900 hover:bg-gray-800 text-white border border-gray-900"
                  onClick={handleStartChat}
                  disabled={!legalArea || !!fileError}
                >
                  Start Consultation
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="max-w-7xl mx-auto h-[90vh] flex flex-col p-6">
          <Card className="flex-1 flex flex-col border mb-4">
            <CardContent className="flex-1 flex flex-col p-6 pb-0">
              <div className="flex items-center justify-between mb-6 pb-4 border-b">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    Legal Consultation
                  </h3>
                  <div className="text-sm text-gray-500 mt-1">
                    {language} • {legalArea} •{" "}
                    {TIMEFRAMES.find((t) => t.value === timeframe)?.label}
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={handleReset}
                  className="text-gray-700 hover:bg-gray-50 border-gray-300"
                >
                  Reset Session
                </Button>
              </div>

              <ScrollArea
                ref={scrollAreaRef}
                className="flex-1 pr-4 mb-4"
                onScroll={() => {
                  // Handle manual scroll if needed
                }}
              >
                <div className="space-y-4">
                  {messages.length === 0 && (
                    <div className="text-center text-gray-400 py-12">
                      <div className="text-lg font-medium">
                        Begin your legal consultation
                      </div>
                      <div className="text-sm mt-2">
                        Ask about case law, regulations, or document analysis
                      </div>
                    </div>
                  )}

                  {messages.map((msg, i) => (
                    <div
                      key={i}
                      className={`flex ${
                        msg.role === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-[75%] px-4 py-3 rounded-lg ${
                          msg.role === "user"
                            ? "bg-gray-900 text-white"
                            : "bg-gray-50 text-gray-900"
                        }`}
                      >
                        {msg.role == "user" ? (
                          msg.content
                        ) : (
                          <div
                            dangerouslySetInnerHTML={{ __html: msg.content }}
                          />
                        )}
                      </div>
                    </div>
                  ))}

                  {loading && (
                    <div className="flex justify-start">
                      <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-lg">
                        <Loader2 className="animate-spin w-5 h-5 text-gray-500" />
                        <span className="text-gray-600">Analyzing...</span>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              <div className="sticky bottom-0 bg-white pt-4 pb-4">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSend();
                  }}
                  className="bg-white border-t pt-4"
                >
                  {apiError && (
                    <div className="text-red-500 text-sm mb-2">{apiError}</div>
                  )}
                  <div className="flex gap-3">
                    <Textarea
                      className="flex-1 resize-none min-h-[100px] text-sm border-gray-300"
                      placeholder="Type your legal query..."
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={handleKeyDown}
                      disabled={loading}
                    />
                    <Button
                      type="submit"
                      disabled={loading || !input.trim()}
                      className="self-end bg-gray-900 hover:bg-gray-800 text-white border border-gray-900"
                    >
                      {loading ? (
                        <Loader2 className="animate-spin h-5 w-5" />
                      ) : (
                        "Send"
                      )}
                    </Button>
                  </div>
                  {file && (
                    <div className="text-sm text-gray-500 mt-2 flex items-center gap-2">
                      <span>📎 Attached:</span>
                      <span className="font-medium">{file.name}</span>
                    </div>
                  )}
                </form>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

// -------------------------------------------------------------------------------------------

// "use client";
// import { useState } from "react";
// import { Button } from "@/components/ui/button";
// import { Textarea } from "@/components/ui/textarea";
// import { Loader2 } from "lucide-react";
// import { LegalFilters } from "@/components/legal/LegalFilters";
// import { LegalResponse } from "@/components/legal/LegalResponse";
// import { Label } from "@/components/ui/label";
// import { useToast } from "@/hooks/use-toast";
// import { BackgroundPattern } from "@/custom-components/background-pattern";

// export default function LegalAssistantChatbot() {
//   const { toast } = useToast();
//   const [input, setInput] = useState("");
//   const [language, setLanguage] = useState("English");
//   const [legalArea, setLegalArea] = useState("IPC");
//   const [timeframe, setTimeframe] = useState("all-time");
//   const [response, setResponse] = useState(null);
//   const [isLoading, setIsLoading] = useState(false);

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!input.trim()) {
//       toast({
//         title: "Error",
//         description: "Please enter a query",
//         variant: "destructive",
//       });
//       return;
//     }

//     setIsLoading(true);
//     try {
//       const result = await fetchLegalAnswer(
//         input,
//         language,
//         legalArea,
//         timeframe
//       );
//       setResponse(result);
//       toast({
//         title: "Success",
//         description: "Legal answer retrieved successfully",
//       });
//     } catch (error) {
//       toast({
//         title: "Error",
//         description: "Failed to fetch legal answer. Please try again.",
//         variant: "destructive",
//       });
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const fetchLegalAnswer = async (query, lang, area, time) => {
//     return new Promise((resolve) => {
//       setTimeout(() => {
//         resolve({
//           answer: `This is a legal answer in ${lang} for your query about ${area} laws from the ${time} period.`,
//           citations: "IPC Section 123, RTI Act 2005, Labor Code 134",
//         });
//       }, 2000);
//     });
//   };

//   return (
//     <div className="min-h-screen bg-white">
//       {/* <BackgroundPattern /> */}
//       <div className="container mx-auto px-4 py-12">
//         <div className="max-w-4xl mx-auto space-y-8">
//           <div className="text-center space-y-3">
//             <h1 className="text-4xl font-bold tracking-tight text-black">
//               Legal Assistant
//             </h1>
//             <p className="text-lg text-gray-600">
//               Get instant, accurate answers to your legal questions
//             </p>
//           </div>

//           <div className="bg-white border border-black rounded-lg p-8 space-y-8">
//             <LegalFilters
//               language={language}
//               setLanguage={setLanguage}
//               legalArea={legalArea}
//               setLegalArea={setLegalArea}
//               timeframe={timeframe}
//               setTimeframe={setTimeframe}
//             />

//             <div className="space-y-2">
//               <Label
//                 htmlFor="query"
//                 className="text-sm font-semibold text-black"
//               >
//                 Your Legal Question
//               </Label>
//               <Textarea
//                 id="query"
//                 value={input}
//                 onChange={(e) => setInput(e.target.value)}
//                 placeholder="Enter your detailed legal query about Indian laws..."
//                 className="h-32 resize-y text-black bg-white border-black focus:border-black focus:ring-1 focus:ring-black"
//               />
//             </div>

//             <Button
//               type="submit"
//               onClick={handleSubmit}
//               className="w-full bg-black hover:bg-gray-800 text-white border border-black"
//               disabled={isLoading}
//             >
//               {isLoading ? (
//                 <>
//                   <Loader2 className="mr-2 h-4 w-4 animate-spin" />
//                   Fetching Answer...
//                 </>
//               ) : (
//                 "Get Legal Answer"
//               )}
//             </Button>
//           </div>

//           {response && (
//             <LegalResponse
//               answer={response.answer}
//               citations={response.citations}
//             />
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }
