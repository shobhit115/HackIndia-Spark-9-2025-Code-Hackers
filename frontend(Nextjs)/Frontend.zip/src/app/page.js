import FAQ06 from "@/components/faq-06/faq-06";
import Features04Page from "@/components/features-04/features-04";
import Footer05Page from "@/components/footer-05/footer-05";
import Hero05 from "@/components/hero-05/hero-05";
import Stats02Page from "@/components/stats-02/stats-02";
import Team01Page from "@/components/team-01/team-01";
import { Navbar1 } from "@/custom-components/navbar";

export default function Home() {
  return (
    <div>
      <Navbar1 />

      {/* Hero Section */}
      <Hero05 />


      {/* Features Section */}
      <div id="highlights" className="py-8" >
        <Features04Page />
      </div>

      {/* Team Section */}
      <div id="team" className="py-8" >
        <Team01Page />
      </div>

      {/* Stats Section */}
      <div id="stats" className="py-4" >
        <Stats02Page />
      </div>
      
      {/* FAQ Section */}
      <div id="faq" className="py-4" >
        <FAQ06 />
      </div>

      {/* Footer Section */}
      <div id="footer" className="py-8" >
        <Footer05Page />
      </div>
    </div>
  );
}
