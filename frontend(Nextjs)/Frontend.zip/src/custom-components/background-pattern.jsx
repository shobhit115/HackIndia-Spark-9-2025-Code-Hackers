'use client';

import DotPattern from "@/components/ui/dot-pattern";
import Particles from "@/components/ui/particles";
import { cn } from "@/lib/utils";
import { useTheme } from "next-themes";

export const BackgroundPattern = () => {
  const { resolvedTheme } = useTheme();
  const isLightTheme = resolvedTheme === "light";

  // Adjust particle quantity for different screen sizes
  const particlesQuantity = window.innerWidth > 1024 ? 150 : 100; // More particles on larger screens

  return (
    <>
      {/* Dot pattern with left-center fade instead of central fade */}
      <DotPattern
        width={25}
        height={25}
        cx={0.5}
        cy={0.5}
        cr={1}
        style={{marginTop: 76}}
        className={cn(
          "[mask-image:linear-gradient(to right, rgba(0, 0, 0, 0.3) 20%, black 70%)]", // Left to center fade
          "dark:fill-slate-700",
          "transition-all duration-300" // Smooth transition for theme changes
        )}
      />

      {/* Particles with dynamic quantity and smooth transitions */}
      <Particles
        className="absolute inset-0"
        quantity={particlesQuantity}
        ease={80}
        color={isLightTheme ? "#000" : "#fff"}
        refresh
        style={{ transition: "all 0.5s ease"}} // Smooth transition when switching themes
      />
    </>
  );
};
