// hooks/useVoiceRecognition.js
import { useState, useEffect, useCallback, useRef } from "react";

export function useVoiceRecognition(onResult, onError) {
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef(null);
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    setSupported(
      Boolean(window.SpeechRecognition || window.webkitSpeechRecognition)
    );
  }, []);

  const handleError = useCallback(
    (error) => {
      setIsListening(false);
      onError?.(error);
    },
    [onError]
  );

  const startListening = useCallback(
    (lang = "en-IN") => {
      if (!supported) {
        handleError("Speech recognition not supported in this browser.");
        return;
      }

      if (isListening) {
        handleError("Already listening. Stop current session first.");
        return;
      }

      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = lang;
      recognition.interimResults = false;
      recognition.continuous = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = (event) => {
        let error = event.error;
        if (error === "not-allowed") {
          error = "Microphone access denied";
        }
        handleError(error || "Voice recognition error");
        recognition.abort();
      };

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onResult?.(transcript);
        recognition.stop();
      };

      try {
        recognition.start();
        recognitionRef.current = recognition;
      } catch (error) {
        handleError(error.message);
      }
    },
    [supported, isListening, onResult, handleError]
  );

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  }, []);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  return {
    startListening,
    stopListening,
    isListening,
    supported,
  };
}
